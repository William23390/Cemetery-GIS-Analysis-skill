# 辅助工具接口

四份脚本仅依赖Python 3.10+标准库。导入不会执行分析或写文件。命令中的路径替换为本项目路径；输出选择新的目录，已有同名输出或与输入冲突时拒绝覆盖。工具不批准方案，不判断血缘/等级，也不替代项目的完整分析和实际图件验收。

## 数据预检

```text
python <skill>/scripts/audit_burials.py <project>/burials.csv --config <project>/audit_config.json --out <project>/preflight_run1
```

配置从`assets/audit_config.json`复制。规范字段与模块依赖见[data-contract.md](data-contract.md)。`requested_modules`为非空列表：

| 模块 | 条件（另均需有效墓号及本次扰动策略） |
|---|---|
| points | x/y与已确认平面米制转换/参照 |
| phase_points | points加已确认分期顺序与确定期属 |
| orientation | 合法角度与已确认有向/轴向定义；不要求位置 |
| rectangles | points加可信长宽、单位和墓向；不要求深度 |
| area_count | 可解析长宽/单位及非负整数件数；不要求位置和方向 |

`disturbance_policy`默认`undisturbed_only`。`include_unknown_exploratory`保留未扰动及未知，`all_exploratory`还保留明确扰动；后两者须配置`sample_policy_confirmed=true`体现已有授权。未知仍输出空值/unknown，无法识别的非空值不作为已授权未知悄悄纳入。规范化角度有向模360°、轴向模180°。

输出：

- `audit.json`：请求模块、每模块数量/整体阻断、待核警告、来源/配置哈希。未请求模块失败不改变本次退出码。逐墓问题造成部分可用时仍须阅读，不将退出0读为所有墓完整。
- `candidate_burials.csv`、`excluded.csv`：**相对位置候选**的保留/排除，未按期属再筛。分期主分析须使用`phase_point_candidate`，不能直接全量使用位置候选。
- `analysis_eligibility.csv`：逐墓模块适用性及原因；`area_count_observed`只是字段存在，`area_count_candidate`另含主键/扰动策略。
- `normalized_burials.csv`：所有行规范化值，含不适用行，按适用性表连接筛选。原值仍在只读源表；单位可确认时换算米，未确认不输出伪米值。
- `issues.csv`：逐墓待核项，包括不影响本次模块的问题。

退出0为所请求模块有可用候选且无整体阻断，退出2为需核查/输入无效；两者都不检查最小统计样本量、真实测量可靠性或软件后续能否拟合。

## 选样覆盖

```text
python <skill>/scripts/audit_selection.py <project>/full_register.csv --selected in_primary --strata size_class burial_container --out <project>/coverage_run1
```

输入必须一墓一行，默认主键`tomb_id`，可用`--id 墓号`指定其他列。`--selected`列每行必须显式true/false（也支持1/0、yes/no、是/否、入选/未入选、纳入/排除）；空值不当作未选，“被盗”等扰动术语不能作为选样标记。`--strata`按列分别汇总，不自动交叉、不翻译类别。若要比较全登记→已定位和已定位→主样本，分别运行并明确各自母表，避免混淆条件入选率。

`coverage.csv`中：`register_n`为该类原有墓数，`selected_n`为该类入选数；`inclusion_rate=selected_n/register_n`；`register_composition=register_n/全登记数`；`selected_composition=selected_n/入选总数`。没有入选墓时后者为空而非0。`category_known=false`与空类别表达未知，仍计入总分母。`membership.csv`逐墓逐属性保留入选标记及类别供核销，`selection_audit.json`留来源哈希与总体数量。不输出逆概率权重或代表性结论。

## 聚类稳定性汇总

```text
python <skill>/scripts/cluster_stability.py <project>/executed_runs.json --out <project>/stability_summary_run1
```

输入JSON示意（`SYN`为合成墓号，实际使用真实已执行结果）：

```json
{
  "reference": {"SYN01": "A", "SYN02": "A", "SYN03": "B"},
  "execution_metadata": {"project_run_manifest": "path/to/actual_runs.json"},
  "runs": [
    {"run_id": "r1", "mode": "fixed_k", "scenario": "location_sigma_0.5m",
     "status": "ok", "assignments": {"SYN01": 1, "SYN02": 1, "SYN03": 2}},
    {"run_id": "r2", "mode": "reselect_k", "scenario": "location_sigma_0.5m",
     "status": "infeasible", "reason": "No candidate satisfied the declared minimum group size"}
  ]
}
```

每个成功运行提供完整`assignments`；标签可重命名，按组内对应比较，不按数字相等比较。`selected_k`可省略，由标签数计算；提供时须一致。`fixed_k`组数须与基准一致。失败/无解使用`failed`/`infeasible`并填原因，不保留伪选解；重复墓号JSON键、重复run_id及含混输入被拒绝。

`stability_runs.csv`逐运行报告实际k、最小组规模、共同/并集墓数、各自覆盖和共同墓号上的ARI。少于2个共同墓时ARI为空；全部单组或全部单墓等相同退化分区可能ARI=1，不代表有用模型。`stability_summary.json`按mode+scenario分别报告成功/失败/无解数、k频数、基准k在全部尝试和成功运行中的比例、ARI最小/中位/最大及最小覆盖，不能只报最好或中位运行。

工具**不执行聚类、不选择k、不验证传入mode是否真的重跑全流程**。实际项目另存参数/种子/特征变换/邻接/候选评分和全部尝试清单，检查运行记录完整性。把固定k结果标成reselect_k是上游错误，汇总不能辨认或补救。

## 几何和统计原语

`spatial_primitives.py`可从项目代码导入，无命令行分析入口。`tomb_rectangle`、`power_cells`、`circular_summary`及`pseudo_f`的公式、凸边界限制和退化情况见[methods.md](methods.md)。这是可复用计算部件，不是完整GIS流水线。
