#!/usr/bin/env python3
"""Summarize supplied fixed-k/reselected-k runs; never fits or reselects a model."""

import argparse
import json
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path

from audit_burials import sha256, unknown, write_csv


def validate_assignments(assignments):
    if not isinstance(assignments, dict) or not assignments:
        raise ValueError("Assignments must be a nonempty tomb_id -> group label object")
    for key, label in assignments.items():
        if not isinstance(key, str) or key != key.strip() or unknown(key):
            raise ValueError("Tomb IDs must be nonempty strings without surrounding whitespace")
        if isinstance(label, bool) or not isinstance(label, (str, int)) or unknown(label):
            raise ValueError("Group labels must be known strings or integers")
    # Canonical labels ensure 1 and '1' do not become two groups by accident.
    return {key: str(value).strip() for key, value in assignments.items()}


def adjusted_rand(reference, observed):
    """ARI on common IDs; None if fewer than two observations are shared."""
    common = sorted(set(reference) & set(observed))
    n = len(common)
    if n < 2:
        return None
    choose2 = lambda value: value * (value - 1) // 2
    cells = Counter((reference[key], observed[key]) for key in common)
    a = sum(choose2(value) for value in Counter(reference[key] for key in common).values())
    b = sum(choose2(value) for value in Counter(observed[key] for key in common).values())
    both = sum(choose2(value) for value in cells.values())
    pairs = choose2(n)
    # Integer arithmetic avoids cancellation and treats equivalent degenerate partitions as ARI=1.
    denominator = (a + b) * pairs - 2 * a * b
    return 1.0 if denominator == 0 else 2 * (both * pairs - a * b) / denominator


def summarize(payload):
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    reference = validate_assignments(payload.get("reference"))
    runs = payload.get("runs")
    if not isinstance(runs, list) or not runs:
        raise ValueError("Supply at least one executed run, including failed/infeasible runs")
    reference_k, run_ids = len(set(reference.values())), set()
    details, grouped = [], defaultdict(list)
    for run in runs:
        if not isinstance(run, dict):
            raise ValueError("Each run must be an object")
        run_id, mode, scenario, status = (run.get(key) for key in ("run_id", "mode", "scenario", "status"))
        if not isinstance(run_id, str) or not run_id.strip() or run_id in run_ids:
            raise ValueError("run_id must be nonempty and unique")
        run_ids.add(run_id)
        if mode not in {"fixed_k", "reselect_k"} or not isinstance(scenario, str) or not scenario.strip():
            raise ValueError("Each run needs mode fixed_k/reselect_k and a named scenario")
        if status not in {"ok", "failed", "infeasible"}:
            raise ValueError("status must be ok, failed or infeasible")
        row = {"run_id": run_id, "mode": mode, "scenario": scenario, "status": status,
               "selected_k": None, "n": None, "min_group_n": None, "common_n": None, "union_n": None,
               "reference_coverage": None, "run_coverage": None, "common_union_ratio": None,
               "ari": None, "reason": run.get("reason", "")}
        if status == "ok":
            assignments = validate_assignments(run.get("assignments"))
            k = len(set(assignments.values()))
            if "selected_k" in run and (type(run["selected_k"]) is not int or run["selected_k"] != k):
                raise ValueError("selected_k disagrees with supplied group labels")
            if mode == "fixed_k" and k != reference_k:
                raise ValueError("fixed_k run changed group count; label as reselect_k or resolve failed groups")
            common = len(set(reference) & set(assignments))
            union = len(set(reference) | set(assignments))
            row.update(selected_k=k, n=len(assignments), min_group_n=min(Counter(assignments.values()).values()),
                       common_n=common, union_n=union, reference_coverage=common / len(reference),
                       run_coverage=common / len(assignments), common_union_ratio=common / union,
                       ari=adjusted_rand(reference, assignments))
        elif not row["reason"] or run.get("assignments") or run.get("selected_k") is not None:
            raise ValueError("Failed/infeasible runs need a reason and no selected solution")
        details.append(row)
        grouped[(mode, scenario)].append(row)
    summaries = []
    for (mode, scenario), records in sorted(grouped.items()):
        successful = [row for row in records if row["status"] == "ok"]
        aris = [row["ari"] for row in successful if row["ari"] is not None]
        frequencies = Counter(row["selected_k"] for row in successful)
        summaries.append({"mode": mode, "scenario": scenario, "attempted_n": len(records),
                          "successful_n": len(successful), "failed_n": sum(row["status"] == "failed" for row in records),
                          "infeasible_n": sum(row["status"] == "infeasible" for row in records),
                          "k_frequencies": dict(sorted(frequencies.items())),
                          "reference_k_count": frequencies[reference_k],
                          "reference_k_fraction_all_attempts": frequencies[reference_k] / len(records),
                          "reference_k_fraction_successful": frequencies[reference_k] / len(successful) if successful else None,
                          "ari_defined_n": len(aris), "ari_min": min(aris) if aris else None,
                          "ari_median": statistics.median(aris) if aris else None,
                          "ari_max": max(aris) if aris else None,
                          "min_group_n_min": min((row["min_group_n"] for row in successful), default=None),
                          "reference_coverage_min": min((row["reference_coverage"] for row in successful), default=None)})
    return {"summary_only": True, "reference_n": len(reference), "reference_k": reference_k,
            "execution_metadata": payload.get("execution_metadata", {}), "scenarios": summaries,
            "limitation": "Summarizes provided runs only; does not verify rerun execution, model choice, or archaeological validity."}, details


def audit_stability(input_path, out_dir):
    input_path, out_dir = Path(input_path), Path(out_dir)
    # Reject repeated JSON object keys, including repeated tomb IDs that json.loads otherwise hides.
    def unique_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key: {key}")
            result[key] = value
        return result
    payload = json.loads(input_path.read_text(encoding="utf-8-sig"), object_pairs_hook=unique_pairs)
    summary, details = summarize(payload)
    summary.update(input=str(input_path.resolve()), input_sha256=sha256(input_path))
    paths = [out_dir / name for name in ("stability_summary.json", "stability_runs.csv")]
    if any(path.exists() or path.resolve() == input_path.resolve() for path in paths):
        raise ValueError("Output exists or collides with source; choose a fresh --out directory")
    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(paths[1], list(details[0]), details)
    paths[0].write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="JSON with reference assignments and executed runs")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = audit_stability(args.input, args.out)
    except (OSError, ValueError) as exc:
        print(f"Stability summary failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
