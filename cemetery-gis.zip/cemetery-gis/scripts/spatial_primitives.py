#!/usr/bin/env python3
"""Small geometry/statistics primitives, all coordinates in one metric plane."""

import math


def _finite(*values):
    if not all(math.isfinite(float(value)) for value in values):
        raise ValueError("All values must be finite")


def tomb_rectangle(x, y, length, width, azimuth):
    """Return CCW open ring; azimuth of long axis, north=0, clockwise."""
    x, y, length, width, azimuth = map(float, (x, y, length, width, azimuth))
    _finite(x, y, length, width, azimuth)
    if length <= 0 or width <= 0:
        raise ValueError("length and width must be positive")
    theta = math.radians(azimuth % 360)
    ux, uy = math.sin(theta), math.cos(theta)
    vx, vy = math.cos(theta), -math.sin(theta)
    return [(x + a * length / 2 * ux + b * width / 2 * vx,
             y + a * length / 2 * uy + b * width / 2 * vy)
            for a, b in ((-1, -1), (-1, 1), (1, 1), (1, -1))]


def signed_area(ring):
    if len(ring) < 3:
        return 0.0
    # Remove large coordinate offsets before products (e.g. projected northing).
    ox, oy = ring[0]
    shifted = [(x - ox, y - oy) for x, y in ring]
    return 0.5 * math.fsum(shifted[i][0] * shifted[(i + 1) % len(shifted)][1]
                          - shifted[(i + 1) % len(shifted)][0] * shifted[i][1]
                          for i in range(len(shifted)))


def polygon_area(ring):
    return abs(signed_area(ring))


def _convex_boundary(boundary):
    ring = [tuple(map(float, point)) for point in boundary]
    if any(len(point) != 2 for point in ring):
        raise ValueError("Boundary vertices must be 2D")
    if len(ring) > 1 and ring[0] == ring[-1]:
        ring.pop()
    if len(ring) < 3 or len(set(ring)) != len(ring):
        raise ValueError("Boundary must have at least three distinct vertices")
    _finite(*(value for point in ring for value in point))
    origin_x, origin_y = ring[0]
    ring = [(x - origin_x, y - origin_y) for x, y in ring]
    scale = max(1.0, *(abs(value) for point in ring for value in point))
    tolerance = 1e-12 * scale ** 2
    area = signed_area(ring)
    if abs(area) <= tolerance:
        raise ValueError("Degenerate boundary")
    if area < 0:
        ring.reverse()
    # Every vertex must be to the left of every edge: also rejects star rings.
    for p, q in zip(ring, ring[1:] + ring[:1]):
        for r in ring:
            cross = (q[0] - p[0]) * (r[1] - p[1]) - (q[1] - p[1]) * (r[0] - p[0])
            if cross < -tolerance:
                raise ValueError("Boundary must be convex and non-self-intersecting")
    return ring, (origin_x, origin_y)


def _clip_halfplane(ring, a, b, c):
    """Sutherland-Hodgman clipping to a*x+b*y <= c."""
    if not ring:
        return []
    result = []
    previous = ring[-1]
    f_previous = a * previous[0] + b * previous[1] - c
    for current in ring:
        f_current = a * current[0] + b * current[1] - c
        inside_previous, inside_current = f_previous <= 0, f_current <= 0
        if inside_previous != inside_current:
            fraction = f_previous / (f_previous - f_current)
            result.append((previous[0] + fraction * (current[0] - previous[0]),
                           previous[1] + fraction * (current[1] - previous[1])))
        if inside_current:
            result.append(current)
        previous, f_previous = current, f_current
    deduplicated = []
    for point in result:
        if not deduplicated or point != deduplicated[-1]:
            deduplicated.append(point)
    if len(deduplicated) > 1 and deduplicated[0] == deduplicated[-1]:
        deduplicated.pop()
    return deduplicated if len(deduplicated) >= 3 else []


def power_cells(points, boundary, weights=None):
    """Clip isotropic power diagram to convex ring; weights have squared units.

    Zero weights yield ordinary Voronoi. Empty cells are retained in order.
    Repeated coordinates are rejected, including those with different weights.
    This O(n^2 * vertices) routine is for modest datasets; not anisotropic.
    """
    ring, origin = _convex_boundary(boundary)
    points = [tuple(map(float, point)) for point in points]
    if not points or any(len(point) != 2 for point in points):
        raise ValueError("At least one 2D seed is required")
    _finite(*(value for point in points for value in point))
    if len(set(points)) != len(points):
        raise ValueError("Duplicate seed coordinates; resolve records before tessellation")
    weights = [0.0] * len(points) if weights is None else list(map(float, weights))
    if len(weights) != len(points):
        raise ValueError("There must be exactly one weight per seed")
    _finite(*weights)
    shifted = [(x - origin[0], y - origin[1]) for x, y in points]
    cells = []
    for i, (xi, yi) in enumerate(shifted):
        cell = list(ring)
        for j, (xj, yj) in enumerate(shifted):
            if i == j:
                continue
            a, b = 2 * (xj - xi), 2 * (yj - yi)
            c = xj * xj + yj * yj - xi * xi - yi * yi + weights[i] - weights[j]
            cell = _clip_halfplane(cell, a, b, c)
            if not cell:
                break
        cells.append([(x + origin[0], y + origin[1]) for x, y in cell])
    return cells


def circular_summary(angles, axial=False):
    """Mean north-clockwise angle and resultant length; mean None if undefined."""
    angles = list(map(float, angles))
    if not angles:
        raise ValueError("At least one angle is required")
    _finite(*angles)
    multiplier = 2 if axial else 1
    sx = sum(math.sin(math.radians(angle * multiplier)) for angle in angles) / len(angles)
    cx = sum(math.cos(math.radians(angle * multiplier)) for angle in angles) / len(angles)
    resultant = min(1.0, math.hypot(sx, cx))
    period = 180.0 if axial else 360.0
    mean = None if resultant < 1e-12 else (math.degrees(math.atan2(sx, cx)) / multiplier) % period
    if mean is not None and math.isclose(mean, period, abs_tol=1e-10):
        mean = 0.0
    return {"mean_degrees": mean, "resultant_length": resultant, "axial": axial, "n": len(angles)}


def pseudo_f(features, labels):
    """Calinski-Harabasz statistic; undefined/degenerate cases return None.

    Call on the same scaled Euclidean feature matrix used for clustering.
    This function neither selects k nor validates a spatial constraint.
    """
    features = [list(map(float, row)) for row in features]
    labels = list(labels)
    n = len(features)
    if n != len(labels) or not n:
        raise ValueError("Nonempty features and labels must have equal length")
    p = len(features[0])
    if p == 0 or any(len(row) != p for row in features):
        raise ValueError("Feature rows must have consistent positive dimension")
    _finite(*(value for row in features for value in row))
    groups = {}
    for row, label in zip(features, labels):
        groups.setdefault(label, []).append(row)
    k = len(groups)
    if not 1 < k < n:
        return None
    grand = [sum(row[j] for row in features) / n for j in range(p)]
    within, between = 0.0, 0.0
    for group in groups.values():
        center = [sum(row[j] for row in group) / len(group) for j in range(p)]
        within += sum(sum((row[j] - center[j]) ** 2 for j in range(p)) for row in group)
        between += len(group) * sum((center[j] - grand[j]) ** 2 for j in range(p))
    if within == 0:
        return None
    return (between / (k - 1)) / (within / (n - k))
