#!/usr/bin/env python3
"""Describe selection coverage from a full one-tomb-per-row CSV; no weighting or inference."""

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

from audit_burials import sha256, unknown, write_csv


def selection_flag(value):
    text = str(value).strip().casefold()
    if text in {"true", "1", "yes", "y", "是", "入选", "纳入"}:
        return True
    if text in {"false", "0", "no", "n", "否", "未入选", "排除"}:
        return False
    return None


def audit_selection(input_path, out_dir, selected_column, strata, id_column="tomb_id"):
    input_path, out_dir = Path(input_path), Path(out_dir)
    if not strata or len(set(strata)) != len(strata):
        raise ValueError("Provide distinct nonempty stratum column names")
    with input_path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames or []
        if not headers or any(not h or not h.strip() for h in headers) or len(set(headers)) != len(headers):
            raise ValueError("CSV headers must be named and unique")
        missing = set([id_column, selected_column] + list(strata)) - set(headers)
        if missing:
            raise ValueError(f"Missing columns: {sorted(missing)}")
        rows = list(reader)
    if any(None in row or any(v is None for v in row.values()) for row in rows):
        raise ValueError("CSV row width differs from header")
    if not rows:
        raise ValueError("Empty register")
    ids = [row[id_column].strip() for row in rows]
    if any(unknown(tomb_id) for tomb_id in ids) or len(set(ids)) != len(ids):
        raise ValueError("Missing or duplicate tomb IDs; supply a one-tomb-per-row register")
    flags = [selection_flag(row[selected_column]) for row in rows]
    if any(flag is None for flag in flags):
        raise ValueError("Every selection flag must explicitly be true or false; unknown is not excluded")
    selected_n, total_n = sum(flags), len(rows)
    coverage, membership = [], []
    for stratum in strata:
        categories = [None if unknown(row[stratum]) else row[stratum].strip() for row in rows]
        total_counts = Counter(categories)
        selected_counts = Counter(category for category, flag in zip(categories, flags) if flag)
        for category, n in sorted(total_counts.items(), key=lambda pair: (pair[0] is None, pair[0] or "")):
            selected = selected_counts[category]
            coverage.append({"stratum": stratum, "category": category or "", "category_known": category is not None,
                             "register_n": n, "selected_n": selected, "inclusion_rate": selected / n,
                             "register_composition": n / total_n,
                             "selected_composition": selected / selected_n if selected_n else ""})
        membership.extend({"tomb_id": tomb_id, "selected": flag, "stratum": stratum,
                           "category": category or "", "category_known": category is not None}
                          for tomb_id, flag, category in zip(ids, flags, categories))
    summary = {"input": str(input_path.resolve()), "input_sha256": sha256(input_path),
               "id_column": id_column, "selection_column": selected_column, "strata": list(strata),
               "register_n": total_n, "selected_n": selected_n, "overall_inclusion_rate": selected_n / total_n,
               "scope": "Descriptive coverage only; this does not establish representativeness or infer inclusion probabilities."}
    paths = [out_dir / name for name in ("selection_audit.json", "coverage.csv", "membership.csv")]
    if any(path.exists() or path.resolve() == input_path.resolve() for path in paths):
        raise ValueError("Output exists or collides with source; choose a fresh --out directory")
    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(paths[1], ["stratum", "category", "category_known", "register_n", "selected_n", "inclusion_rate", "register_composition", "selected_composition"], coverage)
    write_csv(paths[2], ["tomb_id", "selected", "stratum", "category", "category_known"], membership)
    paths[0].write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary, coverage


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--selected", required=True, help="Explicit boolean inclusion column")
    parser.add_argument("--strata", required=True, nargs="+")
    parser.add_argument("--id", default="tomb_id", dest="id_column")
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    try:
        summary, _ = audit_selection(args.input, args.out, args.selected, args.strata, args.id_column)
    except (ValueError, OSError, csv.Error) as exc:
        print(f"Selection audit failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
