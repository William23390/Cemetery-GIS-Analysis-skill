#!/usr/bin/env python3
"""Conservative CSV preflight; writes candidates, never approves analysis."""

import argparse
import csv
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path


REQUIRED = (
    "tomb_id", "x", "y", "orientation", "length", "width", "depth",
    "funerary_objects_count", "stage", "disturbed",
)
OPTIONAL = (
    "burial_container", "object_inventory", "sex", "age", "is_child",
    "is_sacrificial", "special_customs", "source_ref",
)
UNKNOWN = {"", "na", "n/a", "null", "none", "nan", "unknown", "未知", "不详", "未记", "待定", "?"}
TRUE = {"true", "1", "yes", "y", "是", "有", "扰动", "被扰动", "被盗", "盗扰", "被打破"}
FALSE = {"false", "0", "no", "n", "否", "无", "未扰动", "未被扰动", "未盗", "未被盗"}
UNIT_SCALE = {"m": 1.0, "cm": 0.01, "mm": 0.001}
ORIENTATIONS = {"north_clockwise_directed", "north_clockwise_axial"}
MODULE_FIELDS = {
    "points": ("x", "y"), "phase_points": ("x", "y", "stage"),
    "orientation": ("orientation",),
    "rectangles": ("x", "y", "orientation", "length", "width"),
    "area_count": ("length", "width", "funerary_objects_count"),
}
POLICIES = {"undisturbed_only", "include_unknown_exploratory", "all_exploratory"}


def unknown(value):
    return str("" if value is None else value).strip().casefold() in UNKNOWN


def boolean(value):
    text = str("" if value is None else value).strip().casefold()
    if text in TRUE:
        return True
    if text in FALSE:
        return False
    return None


def numeric(value):
    if unknown(value):
        return None
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(path, fields, records):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)


def audit(input_path, config_path, out_dir):
    input_path, config_path, out_dir = map(Path, (input_path, config_path, out_dir))
    config = json.loads(config_path.read_text(encoding="utf-8-sig"))
    if not isinstance(config, dict):
        raise ValueError("Config must be a JSON object")
    mapping = config.get("column_map", {})
    if not isinstance(mapping, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in mapping.items()):
        raise ValueError("column_map must map canonical names to source column names")
    with input_path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        headers = reader.fieldnames or []
        if not headers or any(not name or not name.strip() for name in headers):
            raise ValueError("CSV must have nonempty named headers")
        if len(set(headers)) != len(headers):
            raise ValueError("Duplicate CSV headers; resolve before preflight")
        raw_rows = list(reader)
    fields = REQUIRED + OPTIONAL
    sources = {field: mapping.get(field, field) for field in fields}
    used_sources = [name for name in sources.values() if name in headers]
    if len(used_sources) != len(set(used_sources)):
        raise ValueError("A source column maps to multiple canonical fields")
    malformed = [i for i, row in enumerate(raw_rows, 2) if None in row or any(v is None for v in row.values())]
    if malformed:
        raise ValueError(f"CSV row width differs from header at rows {malformed}")
    rows = [{field: str(row.get(sources[field], "") or "").strip() for field in fields} for row in raw_rows]
    missing = [field for field in REQUIRED if sources[field] not in headers]
    requested = config.get("requested_modules", ["phase_points"])
    if not isinstance(requested, list) or not requested or any(not isinstance(m, str) or m not in MODULE_FIELDS for m in requested):
        raise ValueError("requested_modules must be a nonempty list of points, phase_points, orientation, rectangles, area_count")
    if len(set(requested)) != len(requested):
        raise ValueError("requested_modules contains duplicates")
    policy = config.get("disturbance_policy", "undisturbed_only")
    if not isinstance(policy, str) or policy not in POLICIES:
        raise ValueError("Unknown disturbance_policy")
    policy_confirmed = policy == "undisturbed_only" or config.get("sample_policy_confirmed") is True
    blockers = []
    if "tomb_id" in missing:
        blockers.append("missing_column:tomb_id")
    warnings = []
    if not rows:
        blockers.append("empty_dataset")
    cscale = UNIT_SCALE.get(config.get("coordinate_units"))
    dscale = UNIT_SCALE.get(config.get("dimension_units"))
    coordinates_confirmed = (
        cscale is not None and config.get("coordinates_are_planar") is True
        and isinstance(config.get("coordinate_reference"), str)
        and bool(config["coordinate_reference"].strip())
    )
    orientation_confirmed = config.get("orientation_convention") in ORIENTATIONS
    phase_order = config.get("phase_order", [])
    if not isinstance(phase_order, list) or any(not isinstance(p, str) or unknown(p) for p in phase_order):
        raise ValueError("phase_order must be a list of known nonempty strings")
    if len(set(phase_order)) != len(phase_order):
        raise ValueError("phase_order contains duplicates")
    phase_confirmed = config.get("phase_scheme_confirmed") is True and bool(phase_order)
    if not config.get("boundary_source"):
        warnings.append("boundary_not_supplied:Voronoi_and_density_window_require_confirmation")
    ids = Counter(row["tomb_id"] for row in rows if not unknown(row["tomb_id"]))
    duplicates = sorted(key for key, count in ids.items() if count > 1)
    if duplicates:
        blockers.append("duplicate_tomb_ids")
    if any(unknown(row["tomb_id"]) for row in rows):
        blockers.append("missing_tomb_ids")
    module_blocks = {}
    for module, needed in MODULE_FIELDS.items():
        reasons = [f"missing_column:{f}" for f in needed if f in missing]
        if not policy_confirmed:
            reasons.append("confirm_exploratory_sample_policy")
        if policy == "undisturbed_only" and "disturbed" in missing:
            reasons.append("missing_column:disturbed")
        if module in {"points", "phase_points", "rectangles"} and not coordinates_confirmed:
            reasons.append("confirm_planar_coordinate_reference_and_units")
        if module in {"rectangles", "area_count"} and dscale is None:
            reasons.append("confirm_dimension_units")
        if module in {"rectangles", "orientation"} and not orientation_confirmed:
            reasons.append("confirm_orientation_convention")
        if module == "phase_points" and not phase_confirmed:
            reasons.append("confirm_phase_scheme_and_order")
        module_blocks[module] = reasons
    candidate, normalized_rows, excluded, eligibility, issues = [], [], [], [], []
    phase_counts = Counter()
    seen_xy = {}
    duplicate_coordinates = []
    all_xy = {}
    duplicate_coordinates_all = []
    for source_row, row in enumerate(rows, 2):
        tomb_id = row["tomb_id"]
        reasons, row_issues = [], []
        valid_id = not unknown(tomb_id) and ids[tomb_id] == 1
        if not valid_id:
            reasons.append("missing_or_duplicate_tomb_id")
        disturbance = boolean(row["disturbed"])
        disturbance_allowed = policy_confirmed and (
            disturbance is False or policy == "all_exploratory"
            or (policy == "include_unknown_exploratory" and disturbance is None)
        )
        if disturbance is True and not disturbance_allowed:
            reasons.append("disturbed_or_looted")
        elif disturbance is None:
            if not disturbance_allowed:
                reasons.append("disturbance_unknown")
            row_issues.append("confirm_disturbance")
        if not policy_confirmed:
            reasons.append("exploratory_sample_policy_unconfirmed")
        if disturbance is None and not unknown(row["disturbed"]):
            row_issues.append("unrecognized_disturbance_value")
            disturbance_allowed = False
            reasons.append("unrecognized_disturbance_value")
        x, y = numeric(row["x"]), numeric(row["y"])
        if x is None or y is None:
            reasons.append("location_missing_or_invalid")
            row_issues.append("check_location")
        coord_ok = x is not None and y is not None and coordinates_confirmed
        if not coordinates_confirmed:
            reasons.append("coordinate_system_or_units_unconfirmed")
        azimuth = numeric(row["orientation"])
        azimuth_ok = azimuth is not None and 0 <= azimuth <= 360 and orientation_confirmed
        if not azimuth_ok:
            row_issues.append("orientation_missing_invalid_or_unconfirmed")
        dims = {name: numeric(row[name]) for name in ("length", "width", "depth")}
        dims_ok = {name: value is not None and value > 0 and dscale is not None for name, value in dims.items()}
        for name, ok in dims_ok.items():
            if not ok:
                row_issues.append(f"{name}_missing_invalid_or_unit_unconfirmed")
        count = numeric(row["funerary_objects_count"])
        count_ok = count is not None and count >= 0 and count.is_integer()
        if not count_ok:
            row_issues.append("objects_count_missing_or_invalid")
        stage_ok = phase_confirmed and not unknown(row["stage"]) and row["stage"] in phase_order
        if not stage_ok:
            row_issues.append("phase_missing_uncertain_or_unconfirmed")
        base = valid_id and disturbance_allowed
        clean = base and coord_ok
        phased = clean and stage_ok
        geometry_ok = clean and azimuth_ok and dims_ok["length"] and dims_ok["width"]
        normalized = dict(row)
        normalized.update({
            "source_row": source_row, "x": x * cscale if coord_ok else "", "y": y * cscale if coord_ok else "",
            "orientation": azimuth % (180 if config.get("orientation_convention") == "north_clockwise_axial" else 360) if azimuth_ok else "",
            "disturbed": "" if disturbance is None else str(disturbance).lower(),
            "funerary_objects_count": int(count) if count_ok else "",
            "area_m2": dims["length"] * dims["width"] * dscale ** 2 if dims_ok["length"] and dims_ok["width"] else "",
        })
        for name in dims:
            normalized[name] = dims[name] * dscale if dims_ok[name] else ""
        normalized_rows.append(normalized)
        if clean:
            candidate.append(normalized)
            if (x, y) in all_xy:
                duplicate_coordinates_all.append({"tomb_ids": [all_xy[(x, y)], tomb_id]})
            else:
                all_xy[(x, y)] = tomb_id
            if phased:
                phase_counts[row["stage"]] += 1
                key = (row["stage"], x, y)
                if key in seen_xy:
                    duplicate_coordinates.append({"stage": row["stage"], "tomb_ids": [seen_xy[key], tomb_id]})
                else:
                    seen_xy[key] = tomb_id
        else:
            excluded.append({"source_row": source_row, "tomb_id": tomb_id, "reasons": "|".join(reasons)})
        eligibility.append({
            "source_row": source_row, "tomb_id": tomb_id,
            "point_candidate": clean, "phase_point_candidate": phased,
            "orientation_candidate": base and azimuth_ok,
            "rectangle_candidate": geometry_ok, "phase_rectangle_candidate": geometry_ok and stage_ok,
            "area_count_candidate": base and dims_ok["length"] and dims_ok["width"] and count_ok,
            "area_count_observed": dims_ok["length"] and dims_ok["width"] and count_ok,
            "container_observed": not unknown(row["burial_container"]),
            "disturbed_state": "unknown" if disturbance is None else str(disturbance).lower(),
            "issues": "|".join(reasons + row_issues),
        })
        issues.extend({"source_row": source_row, "tomb_id": tomb_id, "issue": item} for item in row_issues)
    if duplicate_coordinates:
        warnings.append("duplicate_coordinates_within_phase:resolve_before_Voronoi;do_not_jitter_silently")
    if duplicate_coordinates_all:
        warnings.append("duplicate_coordinates_all_points:check_phase_and_seed_identity_before_pooled_Voronoi")
    module_keys = {"points": "point_candidate", "phase_points": "phase_point_candidate", "orientation": "orientation_candidate", "rectangles": "rectangle_candidate", "area_count": "area_count_candidate"}
    modules = {}
    for module, key in module_keys.items():
        count = sum(row[key] for row in eligibility)
        reasons = list(module_blocks[module])
        if not count:
            reasons.append("no_eligible_rows")
        modules[module] = {"requested": module in requested, "eligible_rows": count, "excluded_or_pending": len(rows) - count,
                           "blocking_issues": list(dict.fromkeys(blockers + reasons)),
                           "status": "blocked" if blockers or reasons else "available_with_row_review" if issues else "available"}
    for module in requested:
        blockers.extend(f"{module}:{reason}" for reason in module_blocks[module])
        if not modules[module]["eligible_rows"]:
            blockers.append(f"{module}:no_eligible_rows")
    if len(candidate) < 30:
        warnings.append("fewer_than_30_point_candidates:assess_small_sample_limits_per_method")
    for phase, number in phase_counts.items():
        if number < 5:
            warnings.append(f"small_phase:{phase}:n={number}:KDE_or_clustering_may_be_unavailable")
    summary = {
        "status": "needs_review" if blockers else "preflight_ready_not_approved",
        "input": str(input_path.resolve()), "input_sha256": sha256(input_path),
        "config_sha256": sha256(config_path), "source_rows": len(rows),
        "candidate_points": len(candidate), "excluded_or_pending": len(excluded),
        "phase_point_counts": dict(phase_counts), "missing_columns": missing,
        "requested_modules": requested, "modules": modules,
        "disturbance_policy": policy, "sample_policy_confirmed": policy_confirmed,
        "rows_with_issues": len({i["source_row"] for i in issues}),
        "excluded_csv_scope": "point candidates only; all module exclusions are in analysis_eligibility.csv",
        "column_mapping": sources, "duplicate_ids": duplicates,
        "duplicate_coordinates_within_phase": duplicate_coordinates,
        "duplicate_coordinates_all_points": duplicate_coordinates_all,
        "blocking_issues": list(dict.fromkeys(blockers)), "warnings": warnings,
        "units_of_normalized_candidate_csv": "metres; original values remain in original input",
        "approval": "Not granted by this script; use existing authorization or resolve unconfirmed plan items.",
    }
    # Audit outputs must never replace source/config or silently overwrite prior runs.
    out_dir.mkdir(parents=True, exist_ok=True)
    output_names = ("audit.json", "candidate_burials.csv", "excluded.csv", "analysis_eligibility.csv", "issues.csv", "normalized_burials.csv")
    paths = [out_dir / name for name in output_names]
    if any(path.resolve() in {input_path.resolve(), config_path.resolve()} or path.exists() for path in paths):
        raise ValueError("Output exists or collides with input/config; choose a fresh --out directory")
    write_csv(paths[1], ["source_row"] + list(fields) + ["area_m2"], candidate)
    write_csv(paths[2], ["source_row", "tomb_id", "reasons"], excluded)
    write_csv(paths[3], ["source_row", "tomb_id", "point_candidate", "phase_point_candidate", "orientation_candidate", "rectangle_candidate", "phase_rectangle_candidate", "area_count_candidate", "area_count_observed", "container_observed", "disturbed_state", "issues"], eligibility)
    write_csv(paths[4], ["source_row", "tomb_id", "issue"], issues)
    write_csv(paths[5], ["source_row"] + list(fields) + ["area_m2"], normalized_rows)
    paths[0].write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = audit(args.input, args.config, args.out)
    except (OSError, ValueError, csv.Error) as exc:
        print(f"Preflight failed: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({key: result[key] for key in ("status", "source_rows", "candidate_points", "excluded_or_pending", "blocking_issues")}, ensure_ascii=False))
    return 2 if result["blocking_issues"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
